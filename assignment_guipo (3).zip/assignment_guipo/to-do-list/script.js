let taskList = document.getElementById("taskList");

function loadTasks() {
    let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks.forEach(t => createTask(t));
}
loadTasks();

function addTask() {
    let taskText = document.getElementById("taskInput").value;
    if (taskText === "") return;

    createTask(taskText);
    saveTask(taskText);

    document.getElementById("taskInput").value = "";
}

function createTask(text) {
    let li = document.createElement("li");
    li.innerHTML = `
        ${text}
        <span>
            <button onclick="editTask(this)">Edit</button>
            <button onclick="deleteTask(this)">Delete</button>
        </span>`;
    taskList.appendChild(li);
}

function editTask(btn) {
    let li = btn.parentElement.parentElement;
    let newText = prompt("Edit task:", li.childNodes[0].textContent);
    if (newText) {
        li.childNodes[0].textContent = newText;
        updateStorage();
    }
}

function deleteTask(btn) {
    btn.parentElement.parentElement.remove();
    updateStorage();
}

function saveTask(task) {
    let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks.push(task);
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

function updateStorage() {
    let tasks = [];
    document.querySelectorAll("li").forEach(li => {
        tasks.push(li.childNodes[0].textContent);
    });
    localStorage.setItem("tasks", JSON.stringify(tasks));
}