let data = [
    { place: "Delhi", temp: "24°C", condition: "Cloudy", color: "#b3c6ff" },
    { place: "Mumbai", temp: "31°C", condition: "Sunny", color: "yellow" },
    { place: "Chennai", temp: "29°C", condition: "Rainy", color: "#a3d2ca" }
];

function refreshData() {
    let random = data[Math.floor(Math.random() * data.length)];

    document.getElementById("location").innerText = random.place;
    document.getElementById("temp").innerText = random.temp;
    document.getElementById("condition").innerText = random.condition;
    document.getElementById("weatherCard").style.background = random.color;
}